function varargout=labview_interface(varargin)
    %   Creates a  bidirectional connection with LabVIEW. 
    %   LabVIEW Server must be running first.
    %   Example:
    %       labview_interface('127.0.0.1',2000) 
    %       lvread()
    %       lvwrite([1 2 3 4]);
    %
    %   See also LVREAD, LVWRITE.
    %
    %   Author: Eng. Juan Camilo Gomez Cadavid MSc.
    %
warning('off'); %#ok
disp('[Starting LabVIEW-MATLAB Interface...]');
switch nargin
    case 0
        remotehost = '127.0.0.1';
        portconection = 2000;
        timeout = 0.5;
        disp('Usign defaults > localhost:2000');
    case 1
        remotehost = varargin{1};
        portconection = 2000;
        timeout = 0.5;
        disp('Usign defaults > port 2000');
    case 3
        remotehost = varargin{1};
        portconection = varargin{2};
        timeout = varargin{3};
    otherwise
        error('Too much input arguments');
end

if(~ischar(remotehost)) 
    error('No valid remote host, input must be string');
end
try
    instrreset();
    lv=tcpip(remotehost,portconection,...
        'NetworkRole', 'client',...
        'ByteOrder','BigEndian',...
        'TransferDelay','off',...
        'InputBufferSize',1000000,...
        'OutputBufferSize',1000000,...
        'Timeout',timeout,...
        'UserData',[0]); %#ok
    fopen(lv);
    set(0,'UserData', lv)  
    catch ME,
        disp(['LabVIEW server not-connected: ' ME.message]);
end
varargout={};
    try,stop(timerfindall);catch,end %#ok
    try,delete(timerfindall);catch,end %#ok
    
    lvinterface_service = timer('Name','LabVIEW Interface Service','TimerFcn',@dotransfer, 'Period', 0.01,'TasksToExecute',Inf,'ExecutionMode','FixedRate','Tag','labview_interface','UserData',[]);
    start(lvinterface_service)
end
%% DOTRANSFER
function varargout=dotransfer(varargin)
    try
      drawnow();
      interface=get(0,'UserData');
      nofbytes=fread(interface,4);
      this=timerfind('tag','labview_interface');
      nofbytes=swapbytes(typecast(uint8(nofbytes),'int32'));
      data=fread(interface,double(nofbytes));
      dat=swapbytes(typecast(uint8(data),'double'));
      set(this,'UserData',dat)
      OutputData=get(interface,'UserData');
      datout=typecast(swapbytes(double(OutputData)),'uint8');
      lenout=typecast(swapbytes(int32(length(datout))),'uint8');
      fwrite(interface,[lenout(:)' datout(:)'])
   catch ME %#ok
            try
                delete(timerfindall);
            catch
            end
            disp('LabVIEW Interface disconnected');
    end
   varargout={};
end

