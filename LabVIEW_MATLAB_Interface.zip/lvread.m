function varargout=lvread(varargin)
varargout={get(timerfind('tag','labview_interface'),'UserData')};
