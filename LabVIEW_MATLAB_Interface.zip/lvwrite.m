function varargout=lvwrite(varargin)
    try
    validateattributes(varargin{1},{'numeric'},{'vector','double','real'});
    set(get(0,'UserData'),'UserData',varargin{1}(:)');
    catch
    disp('No valid data. Use Only numeric classes.');    
    end;
    varargout={};
